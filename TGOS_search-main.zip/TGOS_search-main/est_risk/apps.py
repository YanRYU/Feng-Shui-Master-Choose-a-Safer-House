from django.apps import AppConfig


class EstRiskConfig(AppConfig):
    name = 'est_risk'
